from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse
from sqlalchemy.exc import IntegrityError
from fastapi.middleware.cors import CORSMiddleware
from app.routes import auth, hospital
from app.config import settings

FRONTEND_ORIGIN = settings.frontend_origin

app = FastAPI(
    title= "Med-Flow Command Center",
    description=" This is sceound app",
    version= "1.0.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins= [FRONTEND_ORIGIN],
    allow_credentials= True,
    allow_methods=["*"],
    allow_headers=["*"]
)

app.include_router(auth.router)
app.include_router(hospital.router)


@app.get("/heath", tags=["heath"])
async def heath() -> dict[str, str]:
    return {'status': 'OK'}